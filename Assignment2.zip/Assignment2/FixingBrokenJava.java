public class FixingBrokenJava {
	/* Because this program contains numerous bugs that cause compiler errors,
	 * we've chosen not to include the source code to this program directly in
	 * the project.  That would cause all sorts of error messages when you were
	 * working on the other parts of the assignment.
	 * 
	 * To get the starter code for this assignment, go to
	 * 
	 *    http://cs106a.stanford.edu/assignments/FixingBrokenJava.txt
	 * 
	 * Then, replace the contents of this file with the one from your web browser.
	 * 
	 * Happy debugging!
	 */
}
